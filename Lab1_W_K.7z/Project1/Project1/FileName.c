
//Lab1 Zad1  

/*#include <stdio.h>

int main() {
    printf("Numer albumu: 134923\n");
    return 0;
}
*/

//Lab1 Zad2
/*#include <stdio.h>

int main() {
    int liczba;
    printf("Podaj liczbe calkowita: ");
    scanf_s("%d", &liczba);

    if (liczba % 2 == 0) {
        printf("Liczba %d jest parzysta.\n", liczba);
    }
    else {
        printf("Liczba %d jest nieparzysta.\n", liczba);
    }

    return 0;
}
*/

//Lab1 Zad3

/* #include <stdio.h>

int main() {
    float liczba1, liczba2;
    printf("Podaj pierwsza liczbe zmiennoprzecinkowa: ");
    scanf_s("%f", &liczba1);
    printf("Podaj druga liczbe zmiennoprzecinkowa: ");
    scanf_s("%f", &liczba2);

    if (liczba1 > liczba2) {
        printf("Liczba %f jest wieksza niz %f\n", liczba1, liczba2);
    }
    else if (liczba2 > liczba1) {
        printf("Liczba %f jest wieksza niz %f\n", liczba2, liczba1);
    }
    else {
        printf("liczby sa rowne\n");
    }

    return 0;
}
*/

//Lab1 zad4

/*#include <stdio.h>

int main() {
    float liczba1, liczba2, liczba3, liczba4, srednia;
    printf("Podaj pierwsza liczbe zmiennoprzecinkowa: ");
    scanf_s("%f", &liczba1);
    printf("Podaj druga liczbe zmiennoprzecinkowa: ");
    scanf_s("%f", &liczba2);
    printf("Podaj trzecia liczbe zmiennoprzecinkowa: ");
    scanf_s("%f", &liczba3);
    printf("Podaj czwarta liczbe zmiennoprzecinkowa: ");
    scanf_s("%f", &liczba4);

    srednia = (liczba1 + liczba2 + liczba3 + liczba4) / 4;
    printf("Srednia arytmetyczna z wprowadzonych liczb to: %f\n", srednia);

    return 0;
}
*/

//Lab1 zad5

#include <stdio.h>

/*int main() {
    char operator;
    float liczba1, liczba2, wynik;

    printf("Wprowadz operator (+, -, *, /): ");
    scanf_s("%c", &operator);
    printf("Wprowadz dwie liczby: ");
    scanf_s("%f %f", &liczba1, &liczba2);

    switch (operator) {
    case '+':
        wynik = liczba1 + liczba2;
        printf("%f + %f = %f\n", liczba1, liczba2, wynik);
        break;
    case '-':
        wynik = liczba1 - liczba2;
        printf("%f - %f = %f\n", liczba1, liczba2, wynik);
        break;
    case '*':
        wynik = liczba1 * liczba2;
        printf("%f * %f = %f\n", liczba1, liczba2, wynik);
        break;
    case '/':
        if (liczba2 != 0) {
            wynik = liczba1 / liczba2;
            printf("%f / %f = %f\n", liczba1, liczba2, wynik);
        }
        else {
            printf("Blad: Dzielenie przez zero!\n");
        }
        break;
    
    }

    return 0;
}
*/


